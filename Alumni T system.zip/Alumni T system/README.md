# The-Laali-Project ✨
We aimed to build a portal that connects Alumni, Mentor and Mentee of an organization that includes an admin panel, Mentor-Mentee
matching, Alumni verification, etc.
<img src="https://i.imgur.com/XHuBTai.png" />
<img src="https://i.imgur.com/MYtjQPy.png" />
