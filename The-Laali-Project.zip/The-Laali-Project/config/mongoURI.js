const dotenv = require("dotenv");

dotenv.config();


module.exports = `mongodb+srv://dheeraj:sustained@cluster0.ikota.mongodb.net/Cluster0?retryWrites=true&w=majority`;
